package sg.nus.iss.miniprojectserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniprojectserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
